import math

d = float(input("sisesta ringi diameeter"))
#d = 120 #ma olen kasutaja
pindala= (d**2)/2
a = math.sqrt(pindala)
#print(a)
print(int(a))