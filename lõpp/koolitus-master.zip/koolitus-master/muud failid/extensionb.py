def other():
        thislist = []
        name = input("your name")
        age = int(input("your age"))
        thislist.append(name)
        thislist.append(age)
        return thislist