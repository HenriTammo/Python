import time

current = time.ctime()

print(current)

time.sleep(2)
print("see lause võttis 2sec aega")

