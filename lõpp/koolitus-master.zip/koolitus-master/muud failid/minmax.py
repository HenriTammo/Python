thislist = [152, 256, 697, 6666]

a = max(thislist)
b = min (thislist)
print (a, b)