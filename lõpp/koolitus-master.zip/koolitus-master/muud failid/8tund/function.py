#Kirjutage funktsioon kolmnurga_pindala, mis võtab argumentideks kolmnurga külgede pikkused, 
#ning tagastab vastava kolmnurga pindala. Eeldame, et argumentide väärtused sobivad kolmnurga 
#küljepikkusteks.

import math
def kolmnurgapindala(): #hetkel funktsioon
    p = (a*b)/2
    return p # return tagastab funktsioonist väärtust

a = int(input("sisesta a"))
b = int(input("sisesta b"))
c = kolmnurgapindala() # saab  kasutada edas pidi väärtust
print(c)
