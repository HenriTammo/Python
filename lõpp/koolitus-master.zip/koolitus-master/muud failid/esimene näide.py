"""import math
ruut =  4**2
print (ruut)
ruutjuur = math.sqrt(4)
print (ruutjuur)
ruutjuur = math.sqrt(ruut)
print (ruutjuur)"""
import math
a = int(input("palun sisesta esimene arv: "))
b = math.pi
print (b*(a**2))
