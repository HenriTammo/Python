def vasatne():
    info = []
    vastane = "Diablo"  
    info.append(vastane)
    return info

def armor(turvis):
    if turvis == "lohe nahk":
        armor = 45
    return armor

def weapon(relv):
    if relv == "põrgu küüned":
        weapon = 100
    return weapon

def magics(maagia):                                 #see on koht mida ei oska hetkel teha
    if maagia == "2xtugevusrünnak":
        magics = 200
    return magics
