import random

kokku = 0
for x in range(2):
    täringud = random.randint(1, 6)
    kokku = kokku + täringud
    print(täringud)
print(kokku)
