#mõõk
#nahastrüü
#toiduained
#joogipoolisega
#võlujook.
#15 kuldmünti
#kõik mis tulevad seikluse käigus
def backpack():
"backpack" : ["#asjad"]



#mõte
def bp(list, items):
    list.append(item)
    return list
 