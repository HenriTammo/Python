
def Nõeluss(list):
    info = []
    osavus = 8
    vastupidavus = 7
    info.append(osavus)
    info.append(vastupidavus)
    return info
    
def PÜGMEE1(list):
    info = []
    osavus = 5
    vastupidavus = 5
    info.append(osavus)
    info.append(vastupidavus)
    return info

def PÜGMEE2(list):
    info = []
    osavus = 5
    vastupidavus = 6
    info.append(osavus)
    info.append(vastupidavus)
    return info

def HUNT1(list):
    info = []
    osavus = 7
    vastupidavus = 7
    info.append(osavus)
    info.append(vastupidavus)
    return info

def HUNT2(list):
    info = []
    osavus = 8
    vastupidavus = 7
    info.append(osavus)
    info.append(vastupidavus)
    return info

def HUNT3(list):
    info = []
    osavus = 7
    vastupidavus = 9
    info.append(osavus)
    info.append(vastupidavus)
    return info

def RÜNKAELUKAS(list):
    info = []
    osavus = 8
    vastupidavus = 11
    info.append(osavus)
    info.append(vastupidavus)
    return info

def SURMAHAUGAS1(list):
    info = []
    osavus = 4
    vastupidavus = 4
    info.append(osavus)
    info.append(vastupidavus)
    return info

def SURMAHAUGAS2(list):
    info = []
    osavus = 4
    vastupidavus = 3
    info.append(osavus)
    info.append(vastupidavus)
    return info

def SURMAHAUGAS3(list):
    info = []
    osavus = 5
    vastupidavus = 4
    info.append(osavus)
    info.append(vastupidavus)
    return info